# Agda formalisation

Please read this README file before making your way through the
formalisation. There are some concepts which may look a bit tricky at
a glance of the code, but which should hopefully be very clear after
reading about the *Structure and Concepts* of our formalisation below.

This directory contains Agda formalisation of the paper's sections:

 - Section 2. Conditional Language
   - Sec 2. [src/Conditionals/Definitions.agda](src/Conditionals/Definitions.agda)
   - Sec 2.3. [src/Conditionals/Calculations.agda](src/Conditionals/Calculations.agda)
   - Sec 2.4. [src/Conditionals/NonDependent.agda](src/Conditionals/NonDependent.agda)
 - Section 3. Checked Exceptions
   - Sec 3. [src/Exceptions/Definitions.agda](src/Exceptions/Definitions.agda)
   - Sec 3.1. [src/Exceptions/Calculations.agda](src/Exceptions/Calculations.agda)
   - Sec 3.2. [src/Exceptions/DerivedRules.agda](src/Exceptions/DerivedRules.agda)
 - Section 4. Lambda Calculus
   - Sec 4. [src/Lambda/Definitions.agda](src/Lambda/Definitions.agda)
   - Sec 4.1. [src/Lambda/Calculations.agda](src/Lambda/Calculations.agda)
 - Section 5. Lambda Calculus with Conditionals and Checked Exceptions
   - Sec 5. [src/Lambda/Extra/Definitions.agda](src/Lambda/Extra/Definitions.agda)
   - Calculations live in:
	 1. [src/Lambda/Extra/Calculations.agda](src/Lambda/Extra/Calculations.agda)
	 2. [src/Lambda/Extra/SemanticRules.agda](src/Lambda/Extra/SemanticRules.agda)
	 3. [src/Lambda/Extra/SyntacticRules.agda](src/Lambda/Extra/SyntacticRules.agda)
 - Other files
   - [src/Everything.agda](src/Everything.agda) for convenience, loads
     and typechecks all the files in the repository.
   - [src/General](src/General) is an Agda module containing the actual
	 calculations for the above languages. As explained below, our 
	 techniques allow us to calculate in general, and instantiate easily
	 to each language.
   - [src/Reasoning](src/Reasoning) contains some generally useful
     definitions and syntaxes for calculational reasoning.

## Structure and Concepts

### Calculations as proofs

Agda does not technically support "calculations". We present the
calculations as proofs, with the only difference being that in the
Agda files, the definitions come first and the proofs follow. This is
as opposed to the calculational style taken in the paper, where the
calculations are first and the definitions fall out. The two are
equivalent. Don't worry, though: the calculations still look identical
to those in the paper!  See
[src/General/Calculations.agda](src/General/Calculations.agda).

### General calculations

An important point about this formalisation is where the calculations
themselves live.

 - A key part of our methodology, described in the paper, is the
   generality of the calculations. We formalise that in Agda in the
   [General](src/General/Calculations.agda) module.
   
 - [General.Definitions](src/General/Definitions.agda) describes sets
   of features which languages may support, for example "has integers
   and addition", "has lambda abstractions", or "is deterministic".
   
 - [General.Calculations](src/General/Calculations.agda) calculates
   semantic typing rules for *any* language supporting certain sets of
   these features.
   
 - We instantiate these calculations to our particular languages, for
   example
   [Conditionals.Calculations](src/Conditionals/Calculations.agda).
   - There is one such file for each language we define.
   - The calculations are instantiated in a sub-module thus named
     `Calculation`.
	 
This means that the "calculation" file for each individual language
may look a little empty. But don't worry -- you can always place your
Emacs cursor over the general calculation's name
(e.g. `Value.literal-rule`) and type `alt+.` to follow the symbol and
find the calculation details.

### Premises, properties, and rules

The `Calculations` modules for each language are structured similarly to
each other. Take a look at
[Conditionals.Calculations](src/Conditionals/Calculations.agda) to
follow along below.

In quite a principled way, these modules are a sequence of
sub-modules:

 - `Premise`: we define propositions describing the form of the
   *premises only* of the semantic typing rules which we come to
   calculate.
   
   These are set aside in this way because they are reused throughout
   the module and some other ones, so it keeps things tidy.
   
 - `Properties`: we define the properties, also called "semantic
   typing rules" or just "rules" in the paper, in terms of the
   premises. This is in fact a record, not a sub-module (though we
   obtain a module from any Agda record anyway).
   
   The properties are parameterised for *any* "type-of" relation. The
   idea is that the calculations prove the properties for semantic
   typing `⊨`, and then `⊢` is defined to satisfy them trivially.
 
 - `Calculation` invokes the general calculations (read above) to
   derive `Properties` for the semantic typing relation.
   
 - `Syntactic` *defines* a second typing relation, the syntactic one,
   in such a way that it trivially satisfies the properties.
   
 - `Fold`: the syntactic typing relation is inductively defined, and
   so we define a fold, i.e. catamorphism, over it.
   
 - `Smallest`: explicitly spells out the fact that the fold operator
   given above is precisely a proof of "syntactic typing is the
   smallest relation satisfying the properties". That is, it implies
   any other such relation.
   
 - `SoundnessProof`: the "smallest" property of syntactic typing is
   invoked, with the proof that semantic typing *is* a relation
   satisfying the rules also, to immediately show its type soundness.
   
### Derived and refined typing rules

In each of the languages, the paper begins by deriving the most
general type system that we are able to, followed by a "weakening"
into further type systems which are valid too, permit fewer valid
type-assignments, but are more "natural" or "useful" in some way.

We formalise these calculations too. For example, in
[Conditionals.NonDependent](src/Conditionals/NonDependent.agda) we
obtain a type system for the conditionals language which does not make
use of the semantics / evaluation in its rules.

Such files are structured much the same as the original `Calculations`
modules. Their `Calculation` submodules will refer to the "old"
calculations, inheriting as many of the prior calculations as possible.

The remaining calculations for the "new" derived rules follow from
generalised calculations defined in
[General.Refine](src/General/Refine.agda). These are similar to the
earlier general calculations, but are structured instead as implications
from certain "old rules" into "new rules".

As an example, the conditionals language uses `If.non-dependent` from
this general module. Given the "if-true rule" and the "if-false rule"
derived earlier, this calculates a new "if rule" that combines the
two.
   
## How to use this?

If you want to check the proofs locally, make sure you have Agda
installed on your machine, then run:

```
agda src/Everything.agda
```

The proofs have been tested on Agda versions:
    - Agda version 2.8.0, with version 2.3 of the Agda standard library
    - Agda version 2.7.0.1, with version 2.1.1 of the Agda standard library

To explore the calculations, definitions, and other proofs, it's best to
use [Emacs](https://agda.readthedocs.io/en/latest/tools/emacs-mode.html)
as your editor. This will let you typecheck (i.e. validate) the proofs
interactively. Additionally, in Emacs `agda-mode`:

  - **Useful:** Go to the definition of the symbol under your cursor
    with `alt+.` (i.e. `option+.` on macOS; `M-.` in Emacs terms).
  - You can then use `alt+,` / `option+,` to go back to where you
    were.
  - Use `ctrl+x` followed by `ctrl+f` to open a file.
  - Typecheck the open file with `ctrl+c` followed by `ctrl+l`.
  
So, you can typecheck the whole project by opening the root file
[src/Everything.agda](src/Everything.agda) and typing `ctrl+c ctrl+l`.
