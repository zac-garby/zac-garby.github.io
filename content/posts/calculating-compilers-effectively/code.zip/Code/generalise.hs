-- Code for the generalisation section from "Calculating Compilers Effectively"

{-# LANGUAGE GADTs #-}
{-# LANGUAGE InstanceSigs #-}

import Data.Functor.Sum

-- Type classes:

data Expr = Val Int | Add Expr Expr | Print Expr
            deriving Show

class Monad m => MonadPrint m where
   printInt :: Int -> m ()

eval :: MonadPrint m => Expr -> m Int
eval (Val n)   = return n
eval (Add x y) = do n <- eval x; m <- eval y; return (n+m)
eval (Print x) = do n <- eval x; printInt n; return n

data PrintSeq a where
   Ret      :: a -> PrintSeq a
   PrintInt :: Int -> PrintSeq a -> PrintSeq a
   deriving Show

instance Functor PrintSeq where
   fmap :: (a -> b) -> PrintSeq a -> PrintSeq b
   fmap f (Ret v)         = Ret (f v)
   fmap f (PrintInt n ps) = PrintInt n (fmap f ps)

instance Applicative PrintSeq where
   pure :: a -> PrintSeq a
   pure = Ret

   (<*>) :: PrintSeq (a -> b) -> PrintSeq a -> PrintSeq b
   Ret f         <*> qs = fmap f qs
   PrintInt n ps <*> qs = PrintInt n (ps <*> qs)

instance Monad PrintSeq where
   return :: a -> PrintSeq a
   return = pure

   (>>=) :: PrintSeq a -> (a -> PrintSeq b) -> PrintSeq b
   Ret v         >>= f = f v
   PrintInt n ps >>= f = PrintInt n (ps >>= f)

instance MonadPrint PrintSeq where
   printInt :: Int -> PrintSeq ()
   printInt n = PrintInt n (Ret ())

instance MonadPrint IO where
   printInt :: Int -> IO ()
   printInt n = print n

class Monad m => MonadState m where
   getInt :: m Int
   setInt :: Int -> m ()

class Monad m => MonadChoice m where
   zero :: m a
   plus :: m a -> m a -> m a

-- Free monads:

data StateSig a where
   GetSig :: (Int -> a) -> StateSig a
   SetSig :: Int -> a -> StateSig a

instance Functor StateSig where
   fmap :: (a -> b) -> StateSig a -> StateSig b
   fmap f (GetSig g)   = GetSig (f . g)
   fmap f (SetSig n x) = SetSig n (f x)

data PrintSig a where
   PrintSig :: Int -> a -> PrintSig a

instance Functor PrintSig where
   fmap :: (a -> b) -> PrintSig a -> PrintSig b
   fmap f (PrintSig n x) = PrintSig n (f x)

data Free f a = Var a | Con (f (Free f a))

type PrintStateSeq a = Free (Sum PrintSig StateSig) a
