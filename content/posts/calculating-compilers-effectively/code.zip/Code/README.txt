The Haskell and Agda source code for the paper

   Calculating Effectful Compilers

Haskell (print.hs, state.hs, non-det.hs)

  In these files we give practical implementations of each of the
  three effects we consider in the paper.  For each one, we include
  the full source code as described in the paper itself, and full
  definitions for each of the concrete effect interpretations.

Agda (print.agda, state.agda, non-det.agda, lemmas.agda)

  As noted in the paper, we use Agda to formally verify the correctness
  of our calculations.  These four files constitute those proofs.
  We use function extensionality, which is postulated in lemmas.agda.

  Each Agda file begins by translating the types and functions from
  Haskell into Agda's syntax.  We prove all relevant results:

     * The functor and monad laws for each effect type
	
     * Compiler correctness
	 
          exec (comp e c) s = do v <- eval e; exec c (v : s)

     * Correctness of the fusion of run and exec:

          exec' c s = run (exec c s) 

  There are some differences between the Agda presentation and that
  given in the paper.  In particular:

     * Agda does not like partial functions, so we augment the stack
       with an arity (essentially making it a vector) and the code with
       tags to describe how it transforms the shape of the stack.  This
       is a standard, straightforward transformation which doesn't
       affect the validity of the proofs, but keeps Agda happy.
   
     * Agda's 'do' notation only permits one monad per file.  So we are
       forced to translate the IO 'do' blocks into binds and lambdas.
   
     * The calculations are presented as "calculational proofs".  Agda
       does not provide any utility for calculating data types and
       functions *during* equational proofs, so we structure these by
       first writing down the calculated definition and then following
       up with the proof that it is correct.
   
       These proofs, while technically not calculations, still follow the
       same steps as in the paper, so the reader can follow along.
