-- Code for the state example from "Calculating Compilers Effectively"

{-# LANGUAGE GADTs #-}
{-# LANGUAGE InstanceSigs #-}

import Control.Monad.State
import Data.IORef
import Prelude hiding (log)

-- A language with state:

data Expr = Val Int | Add Expr Expr | Get | Set Expr
            deriving Show

-- State sequences:

data StateSeq a where
   Ret    :: a -> StateSeq a
   GetInt :: (Int -> StateSeq a) -> StateSeq a
   SetInt :: Int -> StateSeq a -> StateSeq a

inc :: StateSeq ()
inc = GetInt (\n -> SetInt (n+1) (Ret ()))

instance Functor StateSeq where
   fmap :: (a -> b) -> StateSeq a -> StateSeq b
   fmap f (Ret v)       = Ret (f v)
   fmap f (GetInt c)    = GetInt (\n -> fmap f (c n))
   fmap f (SetInt n ss) = SetInt n (fmap f ss)

instance Applicative StateSeq where
   pure :: a -> StateSeq a
   pure = Ret

   (<*>) :: StateSeq (a -> b) -> StateSeq a -> StateSeq b
   Ret f       <*> ts = fmap f ts
   GetInt c    <*> ts = GetInt (\n -> c n <*> ts)
   SetInt n ss <*> ts = SetInt n (ss <*> ts)

instance Monad StateSeq where
   return :: a -> StateSeq a
   return = pure

   (>>=)  :: StateSeq a -> (a -> StateSeq b) -> StateSeq b
   Ret v       >>= f = f v
   GetInt c    >>= f = GetInt (\n -> c n >>= f)
   SetInt n ss >>= f = SetInt n (ss >>= f)

-- Semantics of expressions:

eval :: Expr -> StateSeq Int
eval (Val n)   = return n
eval (Add x y) = do n <- eval x; m <- eval y; return (n+m)
eval (Get)     = getInt
eval (Set x)   = do n <- eval x; setInt n; return n

getInt :: StateSeq Int
getInt = GetInt Ret

setInt :: Int -> StateSeq ()
setInt n = SetInt n (Ret ())

-- Compiler:

data Code = PUSH Int Code | ADD Code | GET Code | SET Code | HALT
            deriving Show

compile :: Expr -> Code
compile e = comp e HALT

comp :: Expr -> Code -> Code
comp (Val n)   c = PUSH n c
comp (Add x y) c = comp x (comp y (ADD c))
comp (Get)     c = GET c
comp (Set x)   c = comp x (SET c)

-- Virtual machine:

type Stack = [Int]

exec :: Code -> Stack -> StateSeq Stack
exec (PUSH n c) s    = exec c (n:s)
exec (ADD c) (n:m:s) = exec c ((m+n):s)
exec (GET c) s       = do n <- getInt; exec c (n:s)
exec (SET c) (n:s)   = do setInt n; exec c (n:s)
exec HALT s          = return s

-- Semantics of state sequences:

run :: StateSeq a -> State Int a
run (Ret v)       = return v
run (GetInt c)    = do n <- get; run (c n)
run (SetInt n ss) = do put n; run ss

exec' :: Code -> Stack -> State Int Stack
exec' (PUSH n c) s    = exec' c (n:s)
exec' (ADD c) (n:m:s) = exec' c ((m+n):s)
exec' (GET c) s       = do n <- get; exec' c (n:s)
exec' (SET c) (n:s)   = do put n; exec' c (n:s)
exec' HALT s          = return s

-- Alternative semantics:

runRef :: StateSeq a -> IORef Int -> IO a
runRef (Ret v) r       = return v
runRef (GetInt c) r    = do n <- readIORef r; runRef (c n) r
runRef (SetInt n ss) r = do writeIORef r n; runRef ss r

runLog :: Show a => StateSeq a -> IORef Int -> IO a
runLog (Ret v) r       = do log "Ret" v; return v
runLog (GetInt c) r    = do n <- readIORef r
                            log "Get" n; runLog (c n) r
runLog (SetInt n ss) r = do writeIORef r n
                            log "Set" n; runLog ss r

log :: Show a => String -> a -> IO ()
log xs x = putStrLn (xs ++ " " ++ show x)
