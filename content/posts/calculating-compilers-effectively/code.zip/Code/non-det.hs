-- Code for the non-determinism example from "Calculating Compilers Effectively"

{-# LANGUAGE GADTs #-}
{-# LANGUAGE InstanceSigs #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE ScopedTypeVariables #-}

import Control.Exception
import Control.Applicative
import GHC.IO (catchException)
import System.Random
import Control.Parallel
import Control.Concurrent.Async
import Prelude hiding (log)

-- A language with non-determinism:

data Expr = Val Int | Add Expr Expr | Fail | Or Expr Expr
            deriving Show

-- Exception trees:

data ChoiceTree a where
   Ret  :: a -> ChoiceTree a
   Zero :: ChoiceTree a
   Plus :: ChoiceTree a -> ChoiceTree a -> ChoiceTree a
   deriving Show

ctree :: ChoiceTree Int
ctree = Plus (Ret 3) (Ret 4)

instance Functor ChoiceTree where
   fmap :: (a -> b) -> ChoiceTree a -> ChoiceTree b
   fmap f (Ret v)    = Ret (f v)
   fmap f Zero       = Zero
   fmap f (Plus x y) = Plus (fmap f x) (fmap f y)

instance Applicative ChoiceTree where
   pure :: a -> ChoiceTree a
   pure = Ret

   (<*>) :: ChoiceTree (a -> b) -> ChoiceTree a -> ChoiceTree b
   Ret f      <*> x          = fmap f x
   Zero       <*> _          = Zero
   _          <*> Zero       = Zero
   Plus x1 y1 <*> Plus x2 y2 = Plus (x1 <*> x2) (y1 <*> y2)

instance Monad ChoiceTree where
   return :: a -> ChoiceTree a
   return = pure
   
   (>>=)  :: ChoiceTree a -> (a -> ChoiceTree b) -> ChoiceTree b
   Ret v    >>= f = f v
   Zero     >>= f = Zero
   Plus x y >>= f = Plus (x >>= f) (y >>= f)

-- Semantics of expressions:

eval :: Expr -> ChoiceTree Int
eval (Val n)   = return n
eval (Add x y) = do n <- eval x; m <- eval y; return (n+m)
eval Fail      = Zero
eval (Or x y)  = Plus (eval x) (eval y)

-- Compiler:

data Code = PUSH Int Code | ADD Code | FAIL | OR Code Code | HALT
            deriving Show

compile :: Expr -> Code
compile e = comp e HALT

comp :: Expr -> Code -> Code
comp (Val n)   c = PUSH n c
comp (Add x y) c = comp x (comp y (ADD c))
comp (Fail)    c = FAIL
comp (Or x y)  c = OR (comp x c) (comp y c)

-- Virtual machine:

type Stack = [Int]

exec :: Code -> Stack -> ChoiceTree Stack
exec (PUSH n c) s    = exec c (n:s)
exec (ADD c) (m:n:s) = exec c ((n+m) : s)
exec FAIL s          = Zero
exec (OR c d) s      = Plus (exec c s) (exec d s)
exec HALT s          = return s

-- Semantics of choice trees:

run :: ChoiceTree a -> [a]
run (Ret v)    = [v]
run Zero       = []
run (Plus x y) = run x ++ run y

runMaybe :: ChoiceTree a -> Maybe a
runMaybe (Ret v)    = Just v
runMaybe Zero       = Nothing
runMaybe (Plus x y) = case runMaybe x of
                         Just v  -> Just v
                         Nothing -> runMaybe y

runTail :: ChoiceTree a -> [ChoiceTree a] -> Maybe a
runTail (Ret v) _     = Just v
runTail Zero []       = Nothing
runTail Zero (y:ys)   = runTail y ys
runTail (Plus x y) ys = runTail x (y : ys)

data MyException = ZERO deriving (Show,Exception)

runExc :: ChoiceTree a -> IO a
runExc (Ret v)    = return v
runExc Zero       = throwIO ZERO
runExc (Plus x y) = catchException (runExc x) (\ZERO -> runExc y)

runRand :: ChoiceTree a -> IO (Maybe a)
runRand (Ret v)    = return (Just v)
runRand Zero       = return Nothing
runRand (Plus x y) = do n :: Int <- randomRIO (1,2)
                        case n of 
                           1 -> runRand x
                           2 -> runRand y

runPar :: ChoiceTree a -> [a]
runPar (Ret v)    = [v]
runPar Zero       = []
runPar (Plus x y) = par a (a ++ b)
                    where
                       a = runPar x
                       b = runPar y

runAsync :: ChoiceTree a -> IO (Maybe a)
runAsync (Ret v)    = return (Just v)
runAsync Zero       = return Nothing
runAsync (Plus x y) = do l <- async (runAsync x)
                         r <- async (runAsync y)
                         first <- waitEither l r
                         case first of
                            Left  Nothing  -> wait r
                            Right Nothing  -> wait l
                            Left  (Just v) -> return (Just v)
                            Right (Just v) -> return (Just v)
