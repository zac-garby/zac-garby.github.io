-- Code for the printing example from "Calculating Compilers Effectively"

{-# LANGUAGE GADTs #-}
{-# LANGUAGE InstanceSigs #-}

-- A language with printing:

data Expr = Val Int | Add Expr Expr | Print Expr
            deriving Show

-- Print sequences:

data PrintSeq a where
    Ret       :: a -> PrintSeq a
    PrintInt  :: Int -> PrintSeq a -> PrintSeq a
    deriving Show

three :: PrintSeq ()
three = PrintInt 1 (PrintInt 2 (PrintInt 3 (Ret ())))

instance Functor PrintSeq where
    fmap :: (a -> b) -> PrintSeq a -> PrintSeq b
    fmap f (Ret v)         = Ret (f v)
    fmap f (PrintInt n ps) = PrintInt n (fmap f ps)

instance Applicative PrintSeq where
    pure :: a -> PrintSeq a
    pure = Ret

    (<*>) :: PrintSeq (a -> b) -> PrintSeq a -> PrintSeq b
    Ret f         <*> qs = fmap f qs
    PrintInt n ps <*> qs = PrintInt n (ps <*> qs)

instance Monad PrintSeq where
    return :: a -> PrintSeq a
    return = pure

    (>>=) :: PrintSeq a -> (a -> PrintSeq b) -> PrintSeq b
    Ret v         >>= f = f v
    PrintInt n ps >>= f = PrintInt n (ps >>= f)

-- Semantics of expressions:

printInt :: Int -> PrintSeq ()
printInt n = PrintInt n (Ret ())

eval :: Expr -> PrintSeq Int
eval (Val n)   = return n
eval (Add x y) = do n <- eval x; m <- eval y; return (n+m)
eval (Print x) = do n <- eval x; printInt n; return n

-- Compiler:

data Code = PUSH Int Code | ADD Code | PRINT Code | HALT
            deriving Show

compile :: Expr -> Code
compile e = comp e HALT

comp :: Expr -> Code -> Code
comp (Val n)   c = PUSH n c
comp (Add x y) c = comp x (comp y (ADD c))
comp (Print x) c = comp x (PRINT c)

-- Virtual machine:

type Stack = [Int]

exec :: Code -> Stack -> PrintSeq Stack
exec (PUSH n c) s    = exec c (n:s)
exec (ADD c) (m:n:s) = exec c ((n+m) : s)
exec (PRINT c) (n:s) = do printInt n; exec c (n:s)
exec HALT s          = return s 

-- Semantics of print sequences:

run :: PrintSeq a -> IO a
run (Ret v)         = return v
run (PrintInt n ps) = do print n; run ps

-- Fusing execution and running:

exec' :: Code -> Stack -> IO Stack
exec' (PUSH n c) s    = exec' c (n:s)
exec' (ADD c) (m:n:s) = exec' c ((n+m) : s)
exec' (PRINT c) (n:s) = do print n; exec' c (n:s)
exec' HALT s          = return s 

-- Alternative semantics:

runStep :: PrintSeq a -> IO a
runStep (Ret v)         = return v
runStep (PrintInt n ps) = do print n; getLine; runStep ps

runPos :: PrintSeq a -> IO a
runPos (Ret v)                     = return v
runPos (PrintInt n ps) | n >= 0    = do print n; runPos ps
                       | otherwise = runPos ps

runList :: PrintSeq a -> [Int]
runList (Ret v)         = []
runList (PrintInt n ps) = n : runList ps

runRev :: PrintSeq a -> PrintSeq a
runRev (Ret v)         = return v
runRev (PrintInt n ps) = do v <- runRev ps; PrintInt n (Ret v)

runMaybe :: PrintSeq a -> Maybe (IO a)
runMaybe (Ret v)                     = Just (return v)
runMaybe (PrintInt n ps) | n >= 0    = do a <- runMaybe ps
                                          return (do print n; a)
                         | otherwise = Nothing

runMaybe' :: PrintSeq a -> IO (Maybe a)
runMaybe' (Ret v)                     = return (Just v)
runMaybe' (PrintInt n ps) | n >= 0    = do print n; runMaybe' ps
                          | otherwise = return Nothing
