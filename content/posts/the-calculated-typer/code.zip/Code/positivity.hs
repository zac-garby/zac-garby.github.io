-- Section 2

-- Expressions:

data Expr = Val Int | Add Expr Expr

eval :: Expr -> Int
eval (Val n)   = n
eval (Add x y) = eval x + eval y

-- Positivity checking:

isPos :: Expr -> Bool
isPos (Val n)   = n > 0
isPos (Add x y) = isPos x && isPos y
