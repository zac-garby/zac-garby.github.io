import Prelude hiding (abs)

-- Section 10

-- Lambda calculus:

data Expr = Val Value | Add Expr Expr | If Expr Expr Expr
          | Abs (Expr -> Expr) | App Expr Expr

data Value = I Int | B Bool | Fn (Value -> Value) | Error | T Type

-- Evaluation:

folde :: (Value -> a) -> (a -> a -> a) -> (a -> a -> a -> a)
      -> ((a -> a) -> a) -> (a -> a -> a) -> (a -> Value) -> Expr -> a
folde val add cond abs app undo = f
   where
      f (Val v)    = val v
      f (Add x y)  = add (f x) (f y)
      f (If x y z) = cond (f x) (f y) (f z)
      f (Abs k)    = abs (f . k . Val . undo)
      f (App x y)  = app (f x) (f y)

eval :: Expr -> Value
eval = folde id add cond abs app id

-- We include the cases for add, cond, abs, and app which were
-- derived from monotonicity, as described in the paper. These
-- are not needed to evaluate expressions, but are needed in
-- order to give proper meaning to the specification inequation.
--
-- We have commented these out to demonstrate that they are not
-- required for texp. In order for tval (eval ...) to work as
-- expected, please feel free to uncomment these clauses.

add :: Value -> Value -> Value
add (I m)   (I n)   = I (m + n)
-- add (T INT) (I n)   = T INT -- derived from monotonicity
-- add (I m)   (T INT) = T INT -- derived from monotonicity
-- add (T INT) (T INT) = T INT -- derived from monotonicity
add _       _       = Error

cond :: Value -> Value -> Value -> Value
cond (B b)    v w = if b then v else w
-- cond (T BOOL) v w = T (tval v /\ tval w) -- derived from monotonicity
cond _        _ _ = Error

abs :: (Value -> Value) -> Value
abs = Fn

app :: Value -> Value -> Value
app (Fn f)       (I m)    = f (I m)
app (Fn f)       (B b)    = f (B b)
-- app (T (FN t u)) (I m)    = T t        -- derived from monotonicity
-- app (T (FN t u)) (B b)    = T u        -- derived from monotonicity
-- app (Fn f)       (T INT)  = f (T INT)  -- derived from monotonicity
-- app (Fn f)       (T BOOL) = f (T BOOL) -- derived from monotonicity
-- app (T (FN t u)) (T INT)  = T t        -- derived from monotonicity
-- app (T (FN t u)) (T BOOL) = T u        -- derived from monotonicity
app _            _        = Error

-- Types:

data Type = INT | BOOL | FN Type Type | ERROR | TOP

tval :: Value -> Type
tval (I m)  = INT
tval (B b)  = BOOL
tval (Fn f) = FN (tval (f (T INT))) (tval (f (T BOOL)))
tval Error  = ERROR
tval (T t)  = t

instance Ord Type where
    -- (<=) :: Type -> Type -> Bool
    ERROR   <= _       = True
    _       <= TOP     = True
    INT     <= INT     = True
    BOOL    <= BOOL    = True
    FN t t' <= FN u u' = t <= u && t' <= u'
    _       <= _       = False

instance Eq Type where
    -- (==) :: Type -> Type -> Bool
    t == t' = t <= t' && t' <= t

(/\) :: Type -> Type -> Type
TOP /\ t' = t'
t /\ TOP  = t
t /\ t'   = if t == t' then t else ERROR

(~>) :: Bool -> Type -> Type
b ~> t = if b then t else TOP

-- Induced ordering on values:

instance Ord Value where
    -- (<=) :: Value -> Value -> Bool
    v <= T t = tval v <= t
    v <= v'  = v == v'

instance Eq Value where
    -- (==) :: Value -> Value -> Bool
    I m   == I n   = m == n
    B b   == B b'  = b == b'
    Error == Error = True
    T t   == T t'  = t == t'
    _     == _     = False

-- Type checking:

texp :: Expr -> Type
texp = folde tval add' cond' abs' app' T

add' :: Type -> Type -> Type
add' t t'  =  ((t <= INT && t' <= INT)                                          ~> INT)
           /\ ((t <= BOOL || t' <= BOOL || t <= FN TOP TOP || t' <= FN TOP TOP) ~> ERROR)

cond' :: Type -> Type -> Type -> Type
cond' t u u'  =  ((t <= BOOL)                   ~> u /\ u')
              /\ ((t <= INT || t <= FN TOP TOP) ~> ERROR)

abs' :: (Type -> Type) -> Type
abs' f  =  FN (f INT) (f BOOL)

app' :: Type -> Type -> Type
app' (FN t t') u  =  ((u <= INT)        ~> t)
                  /\ ((u <= BOOL)       ~> t')
                  /\ ((u <= FN TOP TOP) ~> ERROR)
app' t         u  =  ERROR

-- Utilities:

instance Show Value where
    show (I m)  = "I " ++ show m
    show (B b)  = "B " ++ show b
    show (Fn f) = "Fn (T INT -> " ++ show (f (T INT)) ++ "; T BOOL -> " ++ show (f (T BOOL)) ++ ")"
    show Error  = "Error"
    show (T t)  = "T " ++ show t

instance Show Type where
    show INT              = "INT"
    show BOOL             = "BOOL"
    show ERROR            = "ERROR"
    show TOP              = "TOP"
    show (FN ERROR ERROR) = "... -> ERROR"
    show (FN t ERROR)     = "INT -> " ++ show t
    show (FN ERROR u)     = "BOOL -> " ++ show u
    show (FN t u)         = "(INT -> " ++ show t
                          ++ "; BOOL -> " ++ show u ++ ")"
